package com.example.lab02_calculatorlukyanov;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Float A, B, Res;
    String AA, BB, RRes;
    EditText txA, txB;
    TextView labResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txA = findViewById((R.id.txA));
        txB = findViewById((R.id.txB));

        labResult = findViewById((R.id.txResult));
    }

    public void Operations(View v)
    {
        AA = txA.getText().toString();
        BB = txB.getText().toString();
        if (AA.isEmpty() || BB.isEmpty())
        {
            Log.e("isEmpty", "Text field is empty");
            Toast.makeText(this,"ERROR: text field is empty", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            A = Float.parseFloat(AA);
            B = Float.parseFloat(BB);
        }
        catch (Exception e)
        {
            Log.e("ErrorParse", "Error with parse");
            Toast.makeText(this,"ERROR: invalid numeric data", Toast.LENGTH_SHORT).show();
            return;
        }

        switch (v.getId())
        {
            case R.id.bAdd:
                Res = A + B;
                break;
            case R.id.bSub:
                Res = A - B;
                break;
            case R.id.bMult:
                Res = A * B;
                break;
            case R.id.bDiv:
                if (B == 0) {
                    Log.e("eDivideByZero", "Divide by zero");
                    Toast.makeText(this,"ERROR: divide by zero", Toast.LENGTH_SHORT).show();
                    return;
                }
                Res = A / B;
                break;
            case R.id.bSin:
                Res = (float)Math.sin(A);
                break;
            case R.id.bCos:
                Res = (float)Math.cos(A);
                break;
            case R.id.bTan:
                Res = (float)Math.tan(A);
                break;
            case R.id.bSqrt:
                Res = (float)Math.sqrt(A);
                break;
            case R.id.bPow:
                Res = (float)Math.pow(A, B);
                break;
        }

        RRes = String.valueOf(Res);

        labResult.setText(RRes);
    }

}